import asyncio
import contextlib
import hmac
import json
import os
import plistlib
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Event

from fastapi import FastAPI, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import HTMLResponse, Response, StreamingResponse

from xsignbot import admin, pages, releases, signing, tasks
from xsignbot.core import (
    BotError, INSTALL_SECONDS, LOG, MAX_CERT, MissingObject, NO_CACHE,
    StoreConflict, StoreUnavailable, add_lease, admin_id, app_root, button, env, keyboard,
    now, origin, random_id, read_ticket, say, store, telegram, telegram_file, ticket,
)

SESSION_SECONDS = 1200
APP_ID = re.compile(r"(?:xsign|[a-f0-9]{16})\Z")
SHORT_ID = re.compile(r"[a-f0-9]{16}\Z")


async def maintenance():
    while True:
        try:
            await run_in_threadpool(admin.cleanup_drafts)
            await run_in_threadpool(lambda: store().prune_sessions())
        except (BotError, StoreConflict, StoreUnavailable, releases.ReleaseError) as exc:
            LOG.warning("Maintenance deferred: %s", type(exc).__name__)
        await asyncio.sleep(300)


@contextlib.asynccontextmanager
async def lifespan(_app):
    stop = Event()
    worker = asyncio.create_task(asyncio.to_thread(tasks.serve, process_queued, stop, tasks.parallelism()))
    cleanup = asyncio.create_task(maintenance())
    setup = asyncio.create_task(asyncio.to_thread(configure_telegram))
    try:
        yield
    finally:
        stop.set()
        tasks.WAKE.set()
        cleanup.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await cleanup
        await setup
        await worker


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)


def try_say(chat, text, markup=None):
    try:
        say(chat, text, markup)
    except BotError:
        LOG.warning("Could not deliver bot message")


def queue_purge(chat, root=None):
    deleted = store().catalog()["deleted"]
    roots = [root] if root in deleted else list(deleted) if root is None else []
    if roots:
        tasks.submit([
            ({"kind": "purge", "root": key, "chat": chat}, f"purge:{key}", 0)
            for key in roots
        ], retention=None)


def admin_callback(chat, query):
    telegram("answerCallbackQuery", callback_query_id=query["id"])
    action, *values = query["data"].split(":")[1:]
    if action == "panel":
        admin.panel(chat)
    elif action == "xsign":
        admin.new_draft(chat, "xsign")
    elif action == "new":
        admin.new_draft(chat, random_id())
    elif action == "updates":
        admin.update_choices(chat)
    elif action == "edit" and len(values) == 2 and APP_ID.fullmatch(values[0]) and SHORT_ID.fullmatch(values[1]):
        admin.new_draft(chat, values[0], values[1])
    elif action == "draft":
        admin.status(chat, admin.draft_for(store().catalog()))
    elif action == "list":
        admin.delete_choices(chat)
    elif action == "purge":
        queue_purge(chat)
    elif action == "pick" and len(values) == 1 and APP_ID.fullmatch(values[0]):
        admin.confirm_delete(chat, values[0])
    elif action == "delete" and len(values) == 2 and APP_ID.fullmatch(values[0]) and SHORT_ID.fullmatch(values[1]):
        name, root = admin.mark_deleted(*values)
        queue_purge(chat, root)
        try_say(chat, f"حُذف {name} من القائمة وتوقفت روابط تثبيته.")
    elif action == "cancel" and len(values) == 1:
        def cancel(state):
            admin.editable(state, values[0])
            admin.clear_draft(state)
        store().edit(cancel)
        admin.panel(chat)
    elif action == "publish" and len(values) == 1:
        if not releases.enabled():
            raise BotError("اضبط مستودع GitHub في إعدادات البوت أولاً.")
        draft, lease = admin.reserve_publish(values[0])
        try:
            tasks.enqueue({"kind": "publish", "chat": chat, "draft": draft, "lease": lease},
                          f"publish:{lease}")
        except tasks.QueueUnavailable:
            admin.unlock_publish(draft, lease)
            raise
        try_say(chat, "جاري فحص IPA ونشر التطبيق.")


def session_default():
    return {"files": {}, "expires": now() + SESSION_SECONDS, "seen": []}


def live_session(session):
    timestamp = now()
    batch = session.get("batch")
    stale_batch = batch and batch["deadline"] + tasks.WORKER_LEASE <= timestamp
    if session["expires"] <= timestamp or stale_batch:
        session.clear()
        session.update(session_default())
    return session


def seen(session, update):
    if update in session["seen"]:
        return True
    session["seen"] = (session["seen"] + [update])[-12:]
    session["expires"] = now() + SESSION_SECONDS
    return False


def session_key(chat):
    return f"sessions/{chat}.json"


def receive_certificate(chat, update_id, message):
    document = message["document"]
    ext = Path(document.get("file_name", "")).suffix.lower()
    if ext not in {".p12", ".mobileprovision"}:
        raise BotError("أرسل ملف p12 أو mobileprovision.")
    if document.get("file_size", 0) > MAX_CERT:
        raise BotError("ملف الشهادة أو البروفايل أكبر من الحد المسموح.")

    def receive(state):
        live_session(state)
        if state.get("job"):
            raise BotError("عندك طلب توقيع قيد التنفيذ.")
        if seen(state, update_id):
            return None
        state["files"][ext] = document["file_id"]
        return set(state["files"])

    files = store().update(session_key(chat), session_default, receive)
    if files is not None:
        if len(files) == 2:
            say(chat, "وصلت الشهادة والبروفايل. أرسل كلمة المرور برسالة واحدة.")
        else:
            missing = ".mobileprovision" if ".p12" in files else ".p12"
            say(chat, f"وصل الملف. أرسل الآن {missing}.")


def reserve_records(job, seconds):
    def reserve(state):
        records = list(state["apps"].values())
        if not records:
            raise BotError("ماكو تطبيقات جاهزة للتوقيع حالياً.")
        add_lease(state, job, [app_root(record) for record in records], seconds)
        return sorted(records, key=lambda record: record["id"] != "xsign")

    return store().edit(reserve)


def is_published(record):
    current = store().catalog()["apps"].get(record["id"])
    return current and current["generation"] == record["generation"]


def load_credentials(work, files):
    p12, provision = work / "cert.p12", work / "cert.mobileprovision"
    telegram_file(files[".p12"], p12, MAX_CERT)
    telegram_file(files[".mobileprovision"], provision, MAX_CERT)
    profile = signing.provision_data(provision)
    expiry = profile.get("ExpirationDate")
    if not isinstance(expiry, datetime) or expiry.replace(tzinfo=timezone.utc).timestamp() <= now():
        raise BotError("ملف mobileprovision منتهي أو تاريخ صلاحيته غير صالح.")
    return p12, provision, profile


def sign_one(job, record, work, p12, provision, password, profile):
    if not is_published(record):
        return None
    if not signing.profile_supports(profile, record["bundle"]):
        raise BotError("البروفايل لا يسمح بتوقيع معرّف حزمة هذا التطبيق.")
    directory = work / record["id"]
    directory.mkdir()
    source = directory / "source.ipa"
    output = directory / "signed.ipa"
    releases.download(record["source"], source)
    expanded = record.get("expanded_bytes") or signing.inspect_ipa(source)["expanded_bytes"]
    minimum = expanded + 2 * source.stat().st_size + 16 * 1024 * 1024
    if shutil.disk_usage(directory).free < minimum:
        raise BotError("حجم التطبيق يتجاوز مساحة العمل المتاحة لخدمة البوت.")
    signing.sign(source, output, p12, provision, password)
    metadata = signing.inspect_ipa(output)
    if metadata["bundle"] != record["bundle"]:
        raise BotError("معرّف النسخة الموقعة غير مطابق.")
    if not is_published(record):
        return None
    root = app_root(record)
    prefix = f"results/{root}{job}/"
    info = {
        "app": record, "team": str(profile.get("TeamName", "Apple Developer"))[:128],
        "expiry": profile["ExpirationDate"].strftime("%Y-%m-%d"),
        "expires": now() + INSTALL_SECONDS,
    }
    tasks.enqueue({"kind": "expire", "root": root, "job": job},
                  f"expire:{root}{job}", delay=INSTALL_SECONDS + 60, retention=None)
    info["asset"] = releases.upload(root, f"signed-{job}.ipa", output, "application/octet-stream")
    store().put(prefix + "info.json", info)
    return prefix


def send_result(chat, job, record):
    if not is_published(record):
        return
    token = ticket("install", {"app": record["id"], "gen": record["generation"], "job": job}, INSTALL_SECONDS)
    markup = keyboard((button(record["name"], "green", url=f"{origin()}/api/install?token={token}"),))
    try:
        telegram("sendPhoto", chat_id=chat, photo=releases.asset_bytes(record["image"]),
                 caption=f"{record['name']} جاهز للتثبيت.", reply_markup=markup)
    except BotError:
        say(chat, f"{record['name']} جاهز للتثبيت.", markup)


def pending_dispatch(state, update_id):
    batch = state.get("batch")
    if batch and batch["update"] == update_id and not batch.get("dispatched") and batch["deadline"] > now():
        return batch
    return None


def launch_queued_batch(chat, update_id, password):
    if len(password) > 256 or "\0" in password:
        raise BotError("كلمة المرور غير صالحة.")
    if not releases.enabled():
        raise BotError("مخزن ملفات التوقيع غير مهيأ بعد.")
    current = live_session(store().state(session_key(chat), session_default())[0])
    if current.get("job"):
        batch = pending_dispatch(current, update_id)
    elif update_id in current["seen"]:
        return
    else:
        if len(current["files"]) != 2:
            raise BotError("أرسل ملفي الشهادة والبروفايل أولاً.")
        job = random_id()
        deadline = now() + tasks.DISPATCH_SECONDS
        records = reserve_records(job, tasks.DISPATCH_SECONDS + tasks.WORKER_LEASE)
        snapshot = {record["id"]: record for record in records}

        def claim(state):
            live_session(state)
            if state.get("job"):
                return pending_dispatch(state, update_id)
            if update_id in state["seen"] or len(state["files"]) != 2:
                return None
            seen(state, update_id)
            state["job"] = job
            state["batch"] = {
                "job": job, "update": update_id, "deadline": deadline, "apps": snapshot,
                "pending": {app_id: {} for app_id in snapshot}, "dispatched": False,
            }
            return state["batch"]

        batch = store().update(session_key(chat), session_default, claim)
        if not batch or batch["job"] != job:
            admin.release(job)

    if not batch:
        return
    job = batch["job"]
    sealed = tasks.seal_password(chat, job, password)
    tasks.submit([
        ({"kind": "sign", "chat": chat, "job": job, "app": app_id, "sealed": sealed},
         f"sign:{job}:{app_id}", 0)
        for app_id in batch["pending"]
    ])

    def submitted(state):
        active = state.get("batch")
        if active and active["job"] == job and not active["dispatched"]:
            active["dispatched"] = True
            return True
        return False

    if store().update(session_key(chat), session_default, submitted):
        try_say(chat, f"بدأ توقيع {len(batch['apps'])} تطبيق دفعة واحدة. تصلك نتيجة كل تطبيق عند اكتماله.")


def run_queued_app(message, attempt):
    chat, job, app_id = message["chat"], message["job"], message["app"]
    claim_id = random_id()

    def claim(state):
        batch = state.get("batch")
        if not batch or batch["job"] != job or app_id not in batch["pending"]:
            return None
        work = batch["pending"][app_id]
        if work.get("until", 0) > now():
            raise tasks.RetryAfter(min(30, work["until"] - now()))
        batch["pending"][app_id] = {"claim": claim_id, "until": now() + tasks.WORKER_LEASE}
        return batch["apps"][app_id], state["files"].copy(), batch["deadline"]

    entry = store().update(session_key(chat), session_default, claim)
    if entry is None:
        return
    record, files, deadline = entry
    terminal = True
    try:
        if not is_published(record):
            return
        prefix = f"results/{app_root(record)}{job}/"
        existing, _ = store().state(prefix + "info.json", None)
        if existing and existing["expires"] > now():
            send_result(chat, job, record)
            return
        if deadline <= now():
            raise BotError("انتهت مهلة الدفعة. أعد إرسال طلب التوقيع.")
        password = tasks.open_password(chat, job, message["sealed"])
        with TemporaryDirectory(prefix="xsign-sign-") as directory:
            work = Path(directory)
            p12, provision, profile = load_credentials(work, files)
            if sign_one(job, record, work, p12, provision, password, profile):
                send_result(chat, job, record)
    except BotError as exc:
        try_say(chat, f"{record['name']} — {exc}")
    except releases.ReleaseRateLimit as exc:
        delay = max(exc.retry_after, min(120, 12 * 2 ** min(attempt, 4)))
        if now() + delay < deadline:
            terminal = False
            raise tasks.RetryAfter(delay) from exc
        try_say(chat, f"تأجل رفع {record['name']} بسبب حدود GitHub. أعد المحاولة لاحقاً.")
    except Exception as exc:
        if attempt < 3 and now() < deadline:
            terminal = False
            raise
        LOG.warning("Queued signing failed: %s", type(exc).__name__)
        try_say(chat, f"تعذر تجهيز {record['name']}. جرّب لاحقاً.")
    finally:
        def finish(state):
            batch = state.get("batch")
            if not batch or batch["job"] != job:
                return False
            current = batch["pending"].get(app_id)
            if not current or current.get("claim") != claim_id:
                return False
            if not terminal:
                batch["pending"][app_id] = {}
                return False
            del batch["pending"][app_id]
            if batch["pending"]:
                return False
            state["files"] = {}
            state.pop("batch", None)
            state.pop("job", None)
            return True

        if store().update(session_key(chat), session_default, finish):
            admin.release(job)


def process_queued(message, attempt):
    kind = message["kind"]
    if kind == "sign":
        run_queued_app(message, attempt)
    elif kind == "publish":
        admin.publish(message["chat"], message["draft"], message["lease"])
    elif kind == "purge":
        root = message["root"]
        catalog = store().catalog()
        if root not in catalog["deleted"]:
            return
        busy_until = max((lease["expires"] for lease in catalog["leases"].values()
                          if root in lease["roots"]), default=0)
        if busy_until > now():
            raise tasks.RetryAfter(busy_until - now() + 2)
        admin.purge_deleted(root)
        try_say(message["chat"], "تم حذف ملفات التطبيق وصوره ونسخه الموقعة من Release.")
    elif kind == "expire":
        root, job = message["root"], message["job"]
        if not releases.ROOT.fullmatch(root) or not SHORT_ID.fullmatch(job):
            return
        prefix = f"results/{root}{job}/"
        info, _ = store().state(prefix + "info.json", None)
        if info and info["expires"] > now():
            raise tasks.RetryAfter(info["expires"] - now() + 2)
        releases.delete_signed(root, job)
        store().wipe(prefix)


def same_private_user(message, user_id):
    chat = message.get("chat", {})
    return chat.get("type") == "private" and chat.get("id") == user_id


def handle_update(update):
    administrator = admin_id()
    query = update.get("callback_query")
    if query and isinstance(query.get("data"), str) and query["data"].startswith("a:"):
        owner = query.get("from", {}).get("id")
        if not administrator or owner != administrator or not same_private_user(query.get("message") or {}, owner):
            telegram("answerCallbackQuery", callback_query_id=query["id"], text="هذا الزر للأدمن فقط.")
            return
        try:
            admin_callback(owner, query)
        except BotError as exc:
            say(owner, str(exc))
        return

    message = update.get("message")
    if not message:
        return
    chat = message.get("from", {}).get("id")
    if not isinstance(chat, int) or not same_private_user(message, chat):
        return
    update_id = update.get("update_id")
    if not isinstance(update_id, int):
        return
    text = (message.get("text") or "").strip()
    command = text.split(maxsplit=1)[0].split("@", 1)[0] if text.startswith("/") else ""
    try:
        if command == "/admin":
            if chat == administrator:
                admin.panel(chat)
            return
        if command == "/start":
            markup = keyboard((button("إدارة التطبيقات", callback_data="a:panel"),)) if chat == administrator else None
            say(chat, "أهلاً بك في XSign. أرسل ملف p12 وملف mobileprovision، ثم كلمة المرور لتوقيع التطبيقات المنشورة.", markup)
        elif chat == administrator and (message.get("photo") or text) and not command and admin.update_draft(chat, message):
            return
        elif "document" in message:
            receive_certificate(chat, update_id, message)
        elif text and not command:
            launch_queued_batch(chat, update_id, message["text"])
    except BotError as exc:
        say(chat, str(exc))


async def json_body(request, limit):
    body = bytearray()
    async for chunk in request.stream():
        body.extend(chunk)
        if len(body) > limit:
            raise HTTPException(413, "حجم الطلب يتجاوز الحد.")
    try:
        result = json.loads(body)
        if not isinstance(result, dict):
            raise ValueError
        return result
    except ValueError as exc:
        raise HTTPException(400, "JSON غير صالح.") from exc


@app.get("/")
@app.get("/api")
def health():
    required = ("BOT_TOKEN", "HMAC_SECRET", "GITHUB_REPOSITORY", "GITHUB_TOKEN", "APP_DOMAIN")
    if admin_id() is not None and all(os.environ.get(name, "").strip() for name in required):
        try:
            return {"service": "XSign", "configured": True, "origin": origin()}
        except BotError:
            pass
    return {"service": "XSign", "configured": False}


def webhook_secret():
    explicit = os.environ.get("TELEGRAM_WEBHOOK_SECRET", "").strip()
    if explicit:
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,256}", explicit):
            raise BotError("إعداد سر الويبهوك غير صالح.")
        return explicit
    return hmac.new(env("HMAC_SECRET").encode(), b"xsign-telegram-webhook", "sha256").hexdigest()


def configure_telegram():
    if os.environ.get("XSIGN_REGISTER_WEBHOOK") != "1" or not health()["configured"]:
        return
    try:
        secret = webhook_secret()
        url = f"{origin()}/api/webhook"
        stamp = hmac.new(env("HMAC_SECRET").encode(),
                         f"{url}|{secret}|{env('BOT_TOKEN')}".encode(), "sha256").hexdigest()
        storage = store()
        key = "state/telegram-webhook.json"
        if storage.state(key, {})[0].get("stamp") == stamp:
            return
        telegram("setWebhook", url=url, secret_token=secret,
                 allowed_updates=["message", "callback_query"], drop_pending_updates=False)
        if telegram("getWebhookInfo").get("url") != url:
            raise BotError("Telegram did not confirm the new webhook.")
        storage.put(key, {"stamp": stamp})
        print("XSign webhook connected to Telegram.", flush=True)
    except (BotError, StoreUnavailable) as exc:
        LOG.warning("Telegram webhook registration deferred: %s", type(exc).__name__)


@app.post("/api/webhook")
@app.post("/webhook")
async def webhook(request: Request):
    try:
        expected = webhook_secret()
    except BotError as exc:
        raise HTTPException(503, "الويبهوك غير مهيأ.") from exc
    supplied = request.headers.get("x-telegram-bot-api-secret-token", "")
    if not hmac.compare_digest(supplied.encode(), expected.encode()):
        raise HTTPException(403, "Forbidden")
    update = await json_body(request, 256 * 1024)
    try:
        await run_in_threadpool(handle_update, update)
    except (StoreUnavailable, StoreConflict, BotError, tasks.QueueUnavailable, releases.ReleaseError) as exc:
        LOG.warning("Webhook deferred: %s", type(exc).__name__)
        raise HTTPException(503, "خدمة البوت غير متاحة مؤقتاً.") from exc
    return {"ok": True}


@app.get("/api/admin/upload")
def upload_page():
    headers = {**NO_CACHE, "Content-Security-Policy":
               "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
               "connect-src 'self'; base-uri 'none'; frame-ancestors 'none'"}
    return HTMLResponse(pages.UPLOAD_PAGE, headers=headers)


@app.put("/api/admin/upload/file")
async def upload_action(request: Request):
    token = request.headers.get("x-upload-ticket", "")
    announced = request.headers.get("x-upload-size", "")
    if not re.fullmatch(r"[1-9][0-9]{0,8}", announced):
        raise HTTPException(400, "حجم الملف غير صالح.")
    size = int(announced)
    try:
        draft = await run_in_threadpool(admin.validate_upload, token, size)
        with TemporaryDirectory(prefix="xsign-upload-") as directory:
            path = Path(directory) / "upload.ipa"
            if shutil.disk_usage(path.parent).free < size + 16 * 1024 * 1024:
                raise BotError("مساحة العمل المتاحة لخدمة البوت لا تكفي لهذا الملف.")
            received = 0
            with path.open("wb") as handle:
                async for chunk in request.stream():
                    received += len(chunk)
                    if received > size:
                        raise HTTPException(413, "حجم الملف المرفوع تجاوز الحجم المحدد.")
                    handle.write(chunk)
            if received != size:
                raise BotError("لم يصل الملف كاملاً. أعد الرفع.")
            await run_in_threadpool(admin.finish_upload, draft, path)
        return {"ok": True}
    except BotError as exc:
        raise HTTPException(400, str(exc)) from exc
    except (StoreUnavailable, StoreConflict, releases.ReleaseError) as exc:
        raise HTTPException(503, "مخزن الرفع غير متاح مؤقتاً.") from exc


def install_result(value):
    try:
        claims = read_ticket("install", value)
        record = store().catalog()["apps"].get(claims["app"])
        if not record or record["generation"] != claims["gen"] or not SHORT_ID.fullmatch(claims["job"]):
            raise MissingObject
        prefix = f"results/{app_root(record)}{claims['job']}/"
        info, _ = store().state(prefix + "info.json", None)
        if not info or info["expires"] <= now():
            raise MissingObject
        return prefix, info
    except (BotError, MissingObject, KeyError, TypeError) as exc:
        raise HTTPException(410, "رابط التثبيت منتهي أو حُذف التطبيق.") from exc
    except StoreUnavailable as exc:
        raise HTTPException(503, "التثبيت غير متاح مؤقتاً.") from exc


@app.get("/install")
@app.get("/api/install")
def installation(token: str):
    _, info = install_result(token)
    return HTMLResponse(pages.install_page(info, token), headers=NO_CACHE)


@app.get("/api/install-image")
def install_image(token: str):
    _, info = install_result(token)
    return Response(releases.asset_bytes(info["app"]["image"]), media_type="image/jpeg", headers=NO_CACHE)


@app.get("/plist")
@app.get("/api/plist")
def plist(token: str):
    _, info = install_result(token)
    record = info["app"]
    manifest = {"items": [{"assets": [{"kind": "software-package", "url": f"{origin()}/api/ipa?token={token}"}],
                           "metadata": {"bundle-identifier": record["bundle"], "bundle-version": record["version"],
                                        "kind": "software", "title": record["name"]}}]}
    return Response(plistlib.dumps(manifest), media_type="application/xml", headers=NO_CACHE)


@app.api_route("/api/ipa", methods=["GET", "HEAD"])
def download(token: str, request: Request):
    _, info = install_result(token)
    key = info["asset"]
    wanted = request.headers.get("range")
    if wanted and not re.fullmatch(r"bytes=(?:[0-9]+-[0-9]*|-[0-9]+)", wanted):
        raise HTTPException(416, "Invalid range")
    try:
        if request.method == "HEAD":
            metadata = releases.asset_head(key)
            return Response(headers={**NO_CACHE, "Accept-Ranges": "bytes",
                                     "Content-Length": str(metadata["ContentLength"])},
                            media_type="application/octet-stream")
        obj = releases.asset_object(key, **({"Range": wanted} if wanted else {}))
    except MissingObject as exc:
        raise HTTPException(410, "التطبيق غير متاح.") from exc
    except releases.ReleaseError as exc:
        raise HTTPException(503, "التنزيل غير متاح مؤقتاً.") from exc
    if obj.get("RangeError"):
        raise HTTPException(416, "Invalid range")
    headers = {**NO_CACHE, "Accept-Ranges": "bytes", "Content-Length": str(obj["ContentLength"])}
    if "ContentRange" in obj:
        headers["Content-Range"] = obj["ContentRange"]

    def stream():
        try:
            yield from obj["Body"].iter_chunks(256 * 1024)
        finally:
            obj["Body"].close()

    return StreamingResponse(stream(), status_code=206 if "ContentRange" in obj else 200,
                             headers=headers, media_type="application/octet-stream")
